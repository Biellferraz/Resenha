package com.br.resenha.projetoresenhaboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoResenhaBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
