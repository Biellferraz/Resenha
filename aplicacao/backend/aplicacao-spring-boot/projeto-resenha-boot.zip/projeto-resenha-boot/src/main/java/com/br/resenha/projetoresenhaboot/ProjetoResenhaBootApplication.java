package com.br.resenha.projetoresenhaboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoResenhaBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoResenhaBootApplication.class, args);
	}

}
